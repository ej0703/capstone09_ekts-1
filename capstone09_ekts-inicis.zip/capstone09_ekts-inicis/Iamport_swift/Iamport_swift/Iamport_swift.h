//
//  Iamport_swift.h
//  Iamport_swift
//
//  Created by ngn on 4/30/19.
//  Copyright © 2019 com.ektsMall. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Iamport_swift.
FOUNDATION_EXPORT double Iamport_swiftVersionNumber;

//! Project version string for Iamport_swift.
FOUNDATION_EXPORT const unsigned char Iamport_swiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Iamport_swift/PublicHeader.h>


